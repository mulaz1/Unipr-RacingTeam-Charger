$(document).ready(function () {
//read parameter
    setInterval(
        function(){
                
            $.ajax({
                type: "GET",
                url: "parameter.csv",
                dataType: "text",
                success: function (data) { processDataParameter(data); }
            });
        
            $.ajax({
                type: "GET",
                url: "voltages.csv",
                dataType: "text",
                success: function (data) {processDataVoltage(data); }
            });

            getCurrent();

            $.ajax({
                type: "GET",
                url: "Charger.log",
                dataType: "text",
                success: function (data) { 
                $("#log").text(data)
                $("#log").html($("#log").html().replace(/\n/g,'<br/>'));
                var allTextLines = data.split(/\n/g);
                var allert = [];
                for (var i = 0; i < allTextLines.length; i++){
                    console.log(allTextLines[i])
                    if(allTextLines[i].includes("CRITICAL")){
                        allert.push(allTextLines[i]);
                    }
                }
                if(allert.length != 0){
                    confirm(allert[allert.length - 1]);
                    }
                }
            });
        },1200);  
});

function processDataParameter(allText) {
    var allTextLines = allText.split(/\r\n|\n/);
    var headers = allTextLines[0].split(',');    //get header file
    var lines = [];
    var data = allTextLines[(allTextLines.length) - 2].split(',');   //get last line of file
    if (data.length == headers.length) {
        var tarr = [];
        for (var j = 0; j < headers.length; j++) {
            tarr.push(headers[j] + ":" + data[j]);
            
            if(headers[j] == "Acstatus") {
                if(data[j] == "True") {
                $("#ACplug").text("OK");
                $("#ACplug").removeClass("text-danger");
                $("#ACplug").addClass("text-success");
            } 
                else {
                    $("#ACplug").text("ERROR");
                    $("#ACplug").removeClass("text-success"); 
                    $("#ACplug").addClass("text-danger");
                }
            }

            if(headers[j] == "time") $("#time").text(data[j]);
            if(headers[j] == "OBC_temperature") $("#OBCtemperature").text(parseFloat(data[j]).toFixed(2) + "°C");
            if(headers[j] == "AC_Power") $("#Acpower").text(parseFloat(data[j]).toFixed(2) + "KW"); 
            if(headers[j] == "Error") $("#Error").text(data[j]);
            if(headers[j] == "batteryTemperature") $('#batteryTemperature').text(parseFloat(data[j]).toFixed(2) + "°C"); 
            if(headers[j] == "batteryTemperatureMiddle") $('#batteryTemperatureMIddle').text(parseFloat(data[j]).toFixed(2) + "°C"); 
            if(headers[j] == "SOC"){
                var val = data[j];
                $("#progress").text(Math.trunc(val) + "%");
                str = "width:" + (Math.trunc(val)).toString() + "%";
                $("#bar").attr('style',str);
            }
            
            if((headers[j] == "bulk")&&(data[j] == "True")){
                $("#bulk").text("OK");
                $("#bulk").removeClass("text-danger");
                $("#bulk").addClass("text-success");
            } 
            else {
                $("#bulk").text("ERROR");
                $("#bulk").removeClass("text-success"); 
                $("#bulk").addClass("text-danger");
                $("#bulk-bg").removeClass("left-border-success");
                $("#bulk-bg").addClass("left-border-danger");
            };
        }
        lines.push(tarr);
    }
    console.log(lines);
}

function processDataVoltage(allText){
    var allTextLines = allText.split(/\r\n|\n/);
    var headers = allTextLines[0].split(',');    //get header file
    var lines = [];

    var data = allTextLines[(allTextLines.length) - 2].split(',');   //get last line of file
    console.log(data);
    if (data.length == headers.length) {
        var tarr = [];
        for (var j = 0; j < headers.length; j++) {
            tarr.push(headers[j] + ":" + data[j]);

            if(headers[j] == "battery_voltage") $("#bat-volt").text(parseFloat(data[j]).toFixed(2) + "V");
            
            if(headers[j] == "cells_voltage") $("#max_cell_volt").text(data[j] + "mV");
            if(headers[j] == "VoltageOut") $("#outvolt").text(parseFloat(data[j]).toFixed(2) + "V");
            if(headers[j] == "min_cells_voltage") $("#min_cell_volt").text(data[j] + "mV");

        }
        lines.push(tarr);
    }
    console.log(lines)
}

function generated(){
    $.fileDownload('../Charger.log')
    .done(function () { alert('File download a success!'); })
    .fail(function () { alert('File download failed!'); });
}