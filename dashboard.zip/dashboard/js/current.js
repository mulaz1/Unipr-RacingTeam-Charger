// Set new default font family and font color to mimic Bootstrap's default styling
Chart.defaults.global.defaultFontFamily = Mono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace, '-apple-system,system-ui,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",Arial,sans-serif';
Chart.defaults.global.defaultFontColor = '#858796';

function getCurrent() {
    $.ajax({
        type: "GET",
        url: "current.csv",
        dataType: "text",
        success: function (data) {
            dataset = processDataCurrent(data);
            console.log(dataset);
            chart(dataset);
        }
    });

    $.ajax({
        type: "GET",
        url: "voltages.csv",
        dataType: "text",
        success: function (data) {
            var voltage = processDataVoltageGraph(data); 
            chartVoltage(voltage);
        }
    });
}

function processDataVoltageGraph(data){
    var result = [];
    var lines = data.split("\n"); //get all row 
    var headers = lines[0].split(","); //get header
    console.log(headers);
    for (var i = 1; i < lines.length - 1; i++) {
        var obj = {};
        var currentline = lines[i].split(",");
        for (var j = 0; j < headers.length; j++) {
            if((headers[j] == "cells_voltage") || (headers[j] == "time") || (headers[j] == "min_cells_voltage")){
                console.log(headers[j])
                obj[headers[j]] = currentline[j];
            }
        }
        result.push(obj);
    }
    console.log(result);
    return result;
}

function processDataCurrent(allText) {
    var result = [];
    var lines = allText.split("\n"); //get all row 
    var headers = lines[0].split(","); //get header
    for (var i = 1; i < lines.length - 1; i++) {
        var obj = {};
        var currentline = lines[i].split(",");
        for (var j = 0; j < headers.length; j++) {
            if(headers[j] == "time"){
                obj[headers[j]] = currentline[j];
            }
            else{
                obj[headers[j]] = parseFloat(currentline[j],10);
            }
            if (i == (lines.length - 2) && (headers[j] == "currentOut")){   //quando il valore e' l'ultimo salvato lo stampo 
                $("#outcurrent").text(parseFloat(currentline[j]).toFixed(2) + "A");
                // $("#outcurrentLem").text((parseFloat(currentline[j]).toFixed(2)) + "A");
                console.log('combinator');
            }
        }
        result.push(obj);
    }
    console.log(result);
    return result;
}

function chart(data) {
    var label = [];   
    var datas = [];

    try {
        data.map((item) => {
            label.push(item.time);
            datas.push(item.currentOut);
        });
    } catch (error) {
        console.log(error);
    }

    new Chart(document.getElementById("myAreaChart"), {
        type: 'line',
        data: {
        labels: label,
        datasets: [{ 
                data: datas,
                label: "Charge Current",
                borderColor: "#4e73df",
                fill: false
            }]
        },
        options: {
            animation: false,
            title: {
            display: false,
            },
            maintainAspectRatio: false,
            Responsive: true,
        }
    });
}

function chartVoltage(dataVoltage) {

    var labelVoltageMax = [];
    var dataVoltageMin = [];
    var dataVoltageMax = [];

    try {
        dataVoltage.map((item) => {
            labelVoltageMax.push(item.time);
            dataVoltageMax.push(item.cells_voltage);
            dataVoltageMin.push(item.min_cells_voltage);
        });
    } catch (error) {
        console.log(error);
    }

    new Chart(document.getElementById("myAreaChartVoltage"), {
        type: 'line',
        data: {
        labels: labelVoltageMax,
        datasets:[
            { 
                data: dataVoltageMax,
                label: "Cell Voltage Max",
                borderColor: "#1cc88a",
                fill: false,
                animation: false
            },
            { 
                data: dataVoltageMin,
                label: "Cell Voltage Min",
                borderColor: "#f6c23e",
                fill: false,
                animation: false
            }
        ]
        },
        options: {
            Responsive: true,
            animation: false,
            title: {
            display: true,
            },
            maintainAspectRatio: false,
        }
    });
}